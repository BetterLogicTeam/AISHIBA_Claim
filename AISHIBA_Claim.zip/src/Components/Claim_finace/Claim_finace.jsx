import React from 'react'
import "./Claim_finace.css"

export default function Claim_finace() {
  return (
    <div className='clainnnnn_mainnn'>

    <h1 className='calin_ja'>Aishiba finance</h1>

    <div className="butnnadn mt-4 text-center my-5">
    <button
                    className="heading_btn"
                    // href="https://twitter.com/aishib_pro?s=21"
                    target="_blank"
                  >
                    {" "}
                    <span class="text">Buy Now</span>
                    <span class="blob"></span>
                    <span class="blob"></span>
                    <span class="blob"></span>
                    <span class="blob"></span>
                  </button>
    </div>

    <div className="container mt-5">

    <div className="row my-4">

    
        <div className="col-md-6  text-white">
            <h4 className='text-white'>Stay Updated</h4>
            <p >Subscribe to get latest updates about RenQ's Finance</p>

            <div className='ajd d-flex align-items-center justify-content-between inpuclai'>
                <input type="text" className='inppp' placeholder='Enter Your Email' name="" id="" />
                <button
                    className="heading_btn"
                    // href="https://twitter.com/aishib_pro?s=21"
                    target="_blank"
                  >
                    {" "}
                    <span class="text">Subscribe</span>
                    <span class="blob"></span>
                    <span class="blob"></span>
                    <span class="blob"></span>
                    <span class="blob"></span>
                  </button>
                
            </div>
        </div>
        <div className="col-md-6">
            <h1 className='text-white text-bold'>Join Our Community</h1>
        </div>
        </div>
    </div>
    </div>
  )
}
