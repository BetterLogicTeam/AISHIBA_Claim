export const BRIDGE_URL = "https://bridge.walletconnect.org";
export const RPC_URL = "https://bsc-mainnet.public.blastapi.io";
export const CHAIN_ID = 56;
