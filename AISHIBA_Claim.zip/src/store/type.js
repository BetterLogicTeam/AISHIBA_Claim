export const types = {
    connect_wallet : "CONNECT_WALLET",
    diconnect_wallet:"DISSCONNECT_WALLET"

}